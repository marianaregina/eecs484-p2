# EECS 484 Project 2

Before compiling and running, change the username and password in FakebookOracleMain.java to your uniqname and Oracle password.

To compile, run

```
make
```

To execute, run

```
make query0
```

To time, run

```
make time0
```

Examine the Makefile for other commands you can run or look at the spec.